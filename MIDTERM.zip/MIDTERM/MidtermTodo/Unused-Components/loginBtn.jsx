import React, { Component } from 'react';

class loginBtn extends Component {
    
    render() { 
        return (
            <div className='col'>
                <button className='btn btn-primary'>Login</button>
            </div>
        )
        
    }
}
 
export default loginBtn;