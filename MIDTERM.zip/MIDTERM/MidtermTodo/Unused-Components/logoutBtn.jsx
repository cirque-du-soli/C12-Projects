import React, { Component } from 'react';

class logoutBtn extends Component {
    
    render() { 
        return (
            <div className='col'>
                <button className='btn btn-danger'>Logout</button>
            </div>
        )
        
    }
}
 
export default logoutBtn;